package com.exception;

public class UnknownShowException extends Exception {
	public UnknownShowException() {
		super("Unknown Show Exception");
	}
}
