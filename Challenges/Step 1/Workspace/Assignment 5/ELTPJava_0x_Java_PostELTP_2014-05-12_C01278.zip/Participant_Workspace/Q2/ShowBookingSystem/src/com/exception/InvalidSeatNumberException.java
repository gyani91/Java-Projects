package com.exception;

public class InvalidSeatNumberException extends Exception {
public InvalidSeatNumberException() {
	super(" Invalid Number Of Seats Exception");
}
}
