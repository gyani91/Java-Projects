package com.bean;

public enum Category {
	Geography,History,GK,Science
}
